package com.capstore.capstoreProject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.capstore.model.Inventory;
import com.capstore.model.Product;
import com.capstore.service.IProductService;

@SpringBootApplication
public class CapstoreProjectApplication {
	@Autowired
	private static IProductService productService;

	public static void main(String[] args) {
		SpringApplication.run(CapstoreProjectApplication.class, args);
		
		productService.add(new Product(100, "Redmi","Mobile", 15000, 110, 130,66,"MI") );
		productService.add(new Product(101, "Samsung Note","Mobile", 19000, 160, 200,70,"Samsung") );
		productService.add(new Product(102, "Nokia 5.1 plus","Mobile", 14000, 100, 130,75,"Nokia") );
		productService.add(new Product(103, "vivo y91","Mobile", 10000, 90, 100,50,"Vivo") );


		productService.add(new Inventory(200, "Redmi", "Moblie",17000, "sdklfhjk", "MI", "Available","Mob", 10) );
		productService.add(new Inventory(201, "Samsung Note", "Moblie",15000, "fjkgjf", "Samsung", "Available","Mob", 12) );


	}

}
