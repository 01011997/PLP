package com.capstore.service;

import java.util.List;



import com.capstore.bean.Product;


public interface IProductService {
	

	

	// fetch similar product by type
	public List<Product> findByname(String productcat);
	Product addproduct(Product product);
	Iterable<Product> getAllProduct();

}
