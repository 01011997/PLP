package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;


import com.capstore.bean.Product;


import com.capstore.repo.ProductRepo;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	ProductRepo prodRepo;

		public Product addproduct(Product product) {
			return prodRepo.save(product);
	}

	

	public String deleteProduct(int productId) {
		try {
			prodRepo.deleteById(productId);
			return "Product deleted";
		} catch (EmptyResultDataAccessException e) {
			throw new EmptyResultDataAccessException("No Product Found To delete", productId);
		}
	}
	
	public Iterable<Product> getAllProduct() {
		Iterable<Product> prods = prodRepo.findAll();
		for (Product product : prods) {
			System.out.println(product.getProductcat());
		}
		return prods;
	}
	
	// fetch similar product by category name
	@Override
	public Iterable<Product> findBycategory(String productcat) {
		Iterable<Product> prod = prodRepo.findAll();
		List<Product> products = new ArrayList<Product>();
		for (Product cat : prod) {
			if(cat.getProductcat().equals(productcat))
			products.add(cat);
		}
		return products;
	}

	//fetch similar product by brand
	@Override
	public Iterable<Product> findByBrand(String brand) {
		Iterable<Product>prod=prodRepo.findAll();
		List<Product>products=new ArrayList<Product>();
		for(Product cat:prod)
		{
			if(cat.getBrand().equals(brand))
				products.add(cat);
			
		}
		return products;
	}
	@Override
	public Iterable<Product> findByName(String name) {
		Iterable<Product>prod=prodRepo.findAll();
		List<Product>products=new ArrayList<Product>();
		for(Product cat:prod)
		{
			if(cat.getName().equals(name))
				products.add(cat);
			
		}
		return products;
	}
	
	
	
	

}